
var yoff = 0.0;        // 2nd dimension of perlin noise

function setup() {
  createCanvas(1200, 720);
}

function draw() {
  background(255);

  for (var i = 0; i < 12; i++) {
  	strokeWeight(1);
  	line(0,i*60,width,i*60);
  }

  for (var i = 0; i < 180; i++) {
  	strokeWeight(0.1);
  	line(0,i * 15,width,i * 15);
  }  

  fill(0,150,250,100);
  // We are going to draw a polygon out of the wave points
  //translate(0, 100);
  beginShape(); 
  
  var xoff = 0;       // Option #1: 2D Noise
  // float xoff = yoff; // Option #2: 1D Noise
  
  // Iterate over horizontal pixels
  if (hour() <= 12) {
  	for (var x = 0; x <= width; x += 10) {
    	// Calculate a y value according to noise, map to 
    	var y = map(noise(xoff, yoff), 0, 1, -20 + (60 - minute()) + (12 - hour()) * 60, 20 + (60 - minute()) + (12 - hour()) * 60); // Option #1: 2D Noise
    	// float y = map(noise(xoff), 0, 1, 200,300);    // Option #2: 1D Noise
    
    	// Set the vertex
    	vertex(x, y); 
    	// Increment x dimension for noise
    	xoff += 0.05;
  	}
  }

  if (hour() > 12) {
  	for (var x = 0; x <= width; x += 10) {
    	// Calculate a y value according to noise, map to 
    	var y = map(noise(xoff, yoff), 0, 1, -20 + minute() + ((24 - hour()) * 60), 20 + minute() + ((24 - hour()) * 60)); // Option #1: 2D Noise
    	// float y = map(noise(xoff), 0, 1, 200,300);    // Option #2: 1D Noise
    
    	// Set the vertex
    	vertex(x, y); 
    	// Increment x dimension for noise
    	xoff += 0.05;
  	}
  } 
  // increment y dimension for noise
  yoff += 0.01;
  vertex(width, height);
  vertex(0, height);
  endShape(CLOSE);


}